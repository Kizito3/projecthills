<section class="mailing_list">
        <div class="mail_heading">
            <h3>Join our mailing list to get exclusive updates</h3>
        </div>
        <div class="container">
            <div class="mailing_details">
                <input type="email" name="" id="" placeholder="Enter Your Email Here"> <button>Subscribe</button>
            </div>
        </div>
    </section>
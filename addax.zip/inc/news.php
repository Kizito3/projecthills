<section class="news-section">
        <div class="news-heading"><h2>Latest Industry News  </h2></div>
        <div class="container">
            <div class="news-grid">
                <div class="news_grid_item">
                    <div class="news_img">
                        <img src="images/latest1.png" alt="">
                    </div>
                    <div class="news_date">
                        <a href="">4th October, 2023</a>
                    </div>
                    <div class="news_head">
                        <h5>The Future of Sustaining Farming</h5>
                    </div>
                    <div class="news_details">
                        <p>Lorem ipsum dolor sit amet consectetur. Ultricies vitae donec lacus leo. Vel arcu donec in sit </p>
                    </div>
                    <div class="news_btn"><a href="">Learn More <i class="fa-solid fa-arrow-right icon"></i></a></div>
                </div>
                <div class="news_grid_item">
                <div class="news_img">
                        <img src="images/latest2.png" alt="">
                    </div>
                    <div class="news_date">
                        <a href="">4th October, 2023</a>
                    </div>
                    <div class="news_head">
                        <h5>The Future of Sustaining Farming</h5>
                    </div>
                    <div class="news_details">
                        <p>Lorem ipsum dolor sit amet consectetur. Ultricies vitae donec lacus leo. Vel arcu donec in sit </p>
                    </div>
                    <div class="news_btn"><a href="">Learn More <i class="fa-solid fa-arrow-right icon"></i></a></div>
                </div>
                <div class="news_grid_item">
                <div class="news_img">
                        <img src="images/latest3.png" alt="">
                    </div>
                    <div class="news_date">
                        <a href="">4th October, 2023</a>
                    </div>
                    <div class="news_head">
                        <h5>The Future of Sustaining Farming</h5>
                    </div>
                    <div class="news_details">
                        <p>Lorem ipsum dolor sit amet consectetur. Ultricies vitae donec lacus leo. Vel arcu donec in sit </p>
                    </div>
                    <div class="news_btn"><a href="">Learn More <i class="fa-solid fa-arrow-right icon"></i></a></div>
                </div>
                <div class="news_grid_item">
                <div class="news_img">
                        <img src="images/latest4.png" alt="">
                    </div>
                    <div class="news_date">
                        <a href="">4th October, 2023</a>
                    </div>
                    <div class="news_head">
                        <h5>The Future of Sustaining Farming</h5>
                    </div>
                    <div class="news_details">
                        <p>Lorem ipsum dolor sit amet consectetur. Ultricies vitae donec lacus leo. Vel arcu donec in sit </p>
                    </div>
                    <div class="news_btn"><a href="">Learn More <i class="fa-solid fa-arrow-right icon"></i></a></div>
                </div>
            </div>
        </div>
    </section>